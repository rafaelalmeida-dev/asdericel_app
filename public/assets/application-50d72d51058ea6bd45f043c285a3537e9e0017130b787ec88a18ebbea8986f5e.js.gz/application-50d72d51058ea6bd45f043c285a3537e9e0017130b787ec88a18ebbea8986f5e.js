// // Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "bootstrap"

// JS do Sneat (separado por pastas)
import "./sneat/helpers"
import "./sneat/menu"
import "./controllers/confirm_delete"
;
